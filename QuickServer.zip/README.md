# QuickServerMC
Easily make and manage Minecraft spigot servers to play with your friends!



Instructions/getting started:
  1. Install the latest version of Java.
  2. Download and open QuickServer.exe.
  3. Click "new server" to create a server.
  4. The server settings page will let you set various basic settings, like difficuly, gamemode, etc.
  5. You can connect to your server using your private IP address (google "how to find my private IP address"),
      but only on your personal WiFi / LAN.
  6. Click "How do my friends and I connect to my server?" to connect via the internet.
  
  
Known Problem: I tried creating a new server, and it says it couldn't find the server files!

  Sometimes, the server installer will get messed up the first time you run the program.
  To fix this, go to the folder %appdata%\.Quickserver and delete the folder called BuildTools.
  Then, go to Server Settings>update server  to try again.
