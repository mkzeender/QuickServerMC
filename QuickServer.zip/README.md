# QuickServerMC
Easily make and manage Minecraft spigot servers to play with your friends!



Instructions/getting started:
  1. Install the latest version of Java.
  2. Download QuickServer.zip and extract the files. Run QuickServer.exe
  3. Click "new server" to create a server. The first time you create a server, it will take about 5 minutes to download.
  4. The server settings page will let you set various basic settings, like difficuly, gamemode, etc.
  5. You can connect to your own computer's server by typing LOCALHOST as the server address.
  6. Click "How do my friends and I connect to my server?" to set up connections via the internet.
  
  
Known Problem: I tried creating a new server, and it says it couldn't find the server files!

  Sometimes, the server installer will get messed up the first time you run the program.
  To fix this, press    "Help! Every time I try making a new server it fails"




Third Party Software:


Autohotkey

  Copyright (C) 1989, 1991 Free Software Foundation, Inc.
  51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

  Everyone is permitted to copy and distribute verbatim copies
  of this license document, but changing it is not allowed.
  
  
